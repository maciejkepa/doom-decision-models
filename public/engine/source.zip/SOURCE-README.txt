Corresponding engine source for DOOM: Decision-1 on Foundry.
Install and activate Emscripten 4.0.10, then run: node scripts/build-engine.mjs
Node 24 is required. No npm dependencies are needed for that build command.
The build downloads pinned SDL ports through emsdk and writes public/engine/doom.js and doom.wasm.
See docs/engine-build.md and THIRD_PARTY_NOTICES.md for provenance and licenses.
